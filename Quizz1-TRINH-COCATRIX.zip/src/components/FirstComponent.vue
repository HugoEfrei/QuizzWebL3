<template>
  <h1>Head and shoulder, knee and toes !</h1>
</template>

<script>
export default {
    name: "FirstComponent"
}
</script>

<style>
    h1{
        color: blue;
        font-weight: bolder;
    }
</style>