<template>
 <div class="col">
    <slot name="top"></slot>
    <slot name="middle"></slot>
    <slot name="bottom"></slot>
 </div>
</template>

<script>
export default {
    name: "SlottedCard",
}
</script>

<style>

</style>