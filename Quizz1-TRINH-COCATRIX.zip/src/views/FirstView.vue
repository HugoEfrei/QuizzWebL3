<template>
  <h1>HI !</h1>
  <FirstComponent> </FirstComponent>
</template>

<script>
    import FirstComponent from '@/components/FirstComponent.vue';
    
export default {
    name: "FirstView",
    components:{
    FirstComponent
}
}
</script>

<style>

</style>